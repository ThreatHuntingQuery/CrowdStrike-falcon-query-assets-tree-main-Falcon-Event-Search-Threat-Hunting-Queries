# Title

Parser for Falcon data.

# Description

This includes the parser for CrowdStrike Falcon data, aka FDR. This package must be installed in the Falcon data **repository**. There is no need to install this package anywhere else. Additional content should be installed in linked Falcon data **views** instead of the repository.

# Package Contents

* Falcon data parser.  
