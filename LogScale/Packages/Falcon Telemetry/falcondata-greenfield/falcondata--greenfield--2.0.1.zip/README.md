# Title

Content for Falcon data from the SE team.  

# Install

This package is dependent on the `falcondata/enrich` package. Please ensure `falcondata/enrich` is installed prior to installing this package. 

# Description

This package includes queries and dashboards from the CrowdStrike SE team. The content is fully functional and designed to act as learning examples.

# Package Contents

* Queries.
* Dashboards.
