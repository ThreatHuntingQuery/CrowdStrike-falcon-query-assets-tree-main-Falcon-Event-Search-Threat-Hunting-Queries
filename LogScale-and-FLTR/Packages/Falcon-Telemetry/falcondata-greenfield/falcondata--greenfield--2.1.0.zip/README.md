# :warning: Warning :warning:

This package is **unofficial** and is not a replacement for the [LogScale Package Marketplace](https://library.humio.com/humio-server/packages-marketplace.html). It is primarily used by the CrowdStrike SE team as learning examples. 

# Description

Custom queries and dashboards Falcon telemetry.  

# Install

This package is dependent on the `falcondata/zen` package. Please ensure `falcondata/zen` is installed prior to installing this package. 

# Description

This package includes queries and dashboards from the CrowdStrike SE team. The content is fully functional and designed to act as learning examples.

# Package Contents

* Queries.
* Dashboards.
