# :warning: Warning :warning:

This package is **unofficial** and is not a replacement for the [LogScale Package Marketplace](https://library.humio.com/humio-server/packages-marketplace.html). It is primarily used by the CrowdStrike SE team as learning examples. 

# Description

Standalone parser for Falcon telemetry. You likely do not need this.   

# Description

This includes the parser for CrowdStrike Falcon data, aka FDR. This package must be installed in the Falcon data **repository**. There is no need to install this package anywhere else. Additional content should be installed in linked Falcon data **views** instead of the repository.

# Package Contents

* Falcon data parser.  
